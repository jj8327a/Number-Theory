def rsa(c, n, d):
    b = c**d//n
    r = c**d-b*n
    return r


cipher = [311, 2595, 1186, 2046]
numplain = []
for i in cipher:
    numplain.append(rsa(int(i), 3901, 3345))

print("Numerical Plaintext:", numplain)
